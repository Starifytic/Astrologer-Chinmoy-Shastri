import { useState } from 'react';
import { ArrowUpRight, Check, ChevronRight, Copy, Menu, Plus, X } from 'lucide-react';
import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const services = [
  ['01', 'Vedic astrology', 'A birth-chart reading that puts timing, tendencies and choice into a useful perspective.'],
  ['02', 'Numerology', 'Explore the patterns carried by your name and numbers when you are choosing a direction.'],
  ['03', 'Palmistry', 'A close reading of the lines and mounts of the hand as a living record of character and change.'],
  ['04', 'Tantra guidance', 'A respectful, considered conversation around spiritual practice, energy and personal transformation.'],
  ['05', 'Vastu consultation', 'Bring more intention to the way your home, workspace or business environment supports you.'],
] as const;

const faqs = [
  ['What should I bring to a consultation?', 'For a Vedic astrology reading, your date, exact time and place of birth are helpful. If your birth time is uncertain, mention that when you write in; we can begin with what is known.'],
  ['Are consultations only about prediction?', 'No. The purpose is perspective, not fear. A session looks at patterns and timing, then gives you practical questions to take back into your own decisions.'],
  ['Can we speak about a relationship or business decision?', 'Yes. These are common reasons people seek guidance. Share the context that feels relevant and we will shape the conversation around the decision in front of you.'],
  ['Do you offer online consultations?', 'Please use the appointment form to share your preference. The format and next steps can be discussed directly after your enquiry.'],
];

function StarMap() {
  const labels = [
    ['ARIES', 250, 26], ['TAURUS', 318, 73], ['GEMINI', 360, 158],
    ['CANCER', 337, 244], ['LEO', 268, 292], ['VIRGO', 177, 292],
    ['LIBRA', 104, 246], ['SCORPIO', 75, 158], ['SAGITTARIUS', 115, 73],
  ];
  return (
    <div className="orbit-stage" aria-label="Decorative astrological chart illustration">
      <div className="orbit-glow" />
      <svg className="orbit-svg" viewBox="0 0 430 350" role="img" aria-labelledby="chart-title chart-description">
        <title id="chart-title">A symbolic Vedic astrology chart</title>
        <desc id="chart-description">Concentric circles and fine gold lines surround a central sun point, with signs arranged around the edge.</desc>
        <g transform="translate(215 174)">
          <circle className="orbit-ring-muted" r="144" />
          <circle className="orbit-ring" r="118" />
          <circle className="orbit-dashes" r="129" />
          <circle className="orbit-ring-muted" r="73" />
          <path className="orbit-line" d="M-144 0H144M0-144V144M-102-102L102 102M102-102L-102 102" />
          <path className="orbit-line" d="M-36-64L0-36L36-64L64-36L36 0L64 36L36 64L0 36L-36 64L-64 36L-36 0L-64-36Z" />
          <circle className="orbit-center" r="5" />
          <circle fill="none" stroke="#FDC97C" strokeWidth="1.2" r="17" opacity=".8" />
          <circle fill="#FDC97C" r="2" cx="-62" cy="-94" />
          <circle fill="#F2E8D8" r="2" cx="101" cy="-35" />
          <circle fill="#FDC97C" r="2" cx="-93" cy="44" />
          {labels.map(([label, x, y]) => <text key={label} className="orbit-label" textAnchor="middle" x={Number(x) - 215} y={Number(y) - 174}>{label}</text>)}
        </g>
      </svg>
      <div className="orbit-caption">A chart is a map<br />not a verdict</div>
    </div>
  );
}

function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [submitted, setSubmitted] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const closeMenu = () => setMobileOpen(false);
  const scrollToContact = () => {
    document.getElementById('appointment')?.scrollIntoView({ behavior: 'smooth' });
    closeMenu();
  };
  const copyEnquiry = async () => {
    if (!submitted) return;
    try {
      await navigator.clipboard.writeText(submitted);
      setCopied(true);
    } catch {
      document.getElementById('enquiry-preview')?.focus();
      setCopied(false);
    }
  };

  return (
    <div className="site-shell">
      <header className="site-nav">
        <div className="container nav-inner">
          <a className="brand" href="#top" onClick={closeMenu} data-testid="link-brand">
            <span className="brand-mark" aria-hidden="true">CS</span>
            <span className="brand-copy">Chinmoy Shastri<span>Durgapur · West Bengal</span></span>
          </a>
          <nav className={`nav-links ${mobileOpen ? 'mobile-open' : ''}`} aria-label="Primary navigation">
            <a href="#practice" onClick={closeMenu} data-testid="link-practice">The practice</a>
            <a href="#services" onClick={closeMenu} data-testid="link-services">Services</a>
            <a href="#approach" onClick={closeMenu} data-testid="link-approach">Approach</a>
            <a href="#appointment" onClick={closeMenu} data-testid="link-appointment-mobile">Appointment</a>
          </nav>
          <button className="nav-action" onClick={scrollToContact} data-testid="button-nav-appointment">Begin a conversation <ArrowUpRight size={14} /></button>
          <button className="mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? 'Close menu' : 'Open menu'} aria-expanded={mobileOpen} data-testid="button-mobile-menu">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero" aria-labelledby="hero-title">
          <div className="container hero-inner">
            <div className="hero-copy">
              <div className="eyebrow">Vedic astrology · Numerology · Vastu</div>
              <h1 id="hero-title" className="display">Find a clearer<br /><em>way forward.</em></h1>
              <p className="hero-lede">For the decisions that stay with you — a grounded consultation in astrology and allied practices, held with care and without easy answers.</p>
              <div className="hero-actions">
                <button className="button-primary" onClick={scrollToContact} data-testid="button-hero-appointment">Request an appointment <ArrowUpRight size={15} /></button>
                <a className="button-outline" href="#practice" data-testid="link-hero-practice">How I work <ChevronRight size={15} /></a>
              </div>
              <div className="hero-footnote"><span /> Based in Durgapur, West Bengal · Consultations by prior arrangement</div>
            </div>
            <StarMap />
          </div>
        </section>

        <section id="practice" className="cream-panel section-pad" aria-labelledby="practice-title">
          <div className="container intro">
            <div>
              <div className="eyebrow">A considered practice</div>
              <h2 id="practice-title" className="display intro-title">Look at the whole <span>picture.</span></h2>
            </div>
            <div className="intro-copy">
              <p>Life rarely arrives as one neat question. A career decision can sit beside a relationship, a move, a season of doubt. The work here is to slow the moment down, read its patterns and help you see what is yours to choose.</p>
              <p>Chinmoy Shastri brings together classical Vedic astrology with numerology, palmistry, tantra and Vastu — not as a formula, but as different lenses for a more complete conversation.</p>
              <div className="rule" />
              <div className="facts">
                <div><span className="fact-number">01</span><span className="fact-label">One conversation<br />at a time</span></div>
                <div><span className="fact-number">05</span><span className="fact-label">Ways to read<br />the question</span></div>
                <div><span className="fact-number">03</span><span className="fact-label">Room for your<br />own agency</span></div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="services section-pad" aria-labelledby="services-title">
          <div className="container">
            <div className="section-heading">
              <div><div className="eyebrow">What we can explore</div><h2 id="services-title" className="display">The five lenses.</h2></div>
              <p>Choose the doorway that best matches the question you are carrying. A consultation can also bring more than one lens together.</p>
            </div>
            <div className="service-list">
              {services.map(([number, title, description]) => (
                <article className="service-row" key={number} data-testid={`card-service-${number}`}>
                  <div className="service-index">{number}</div>
                  <div><h3>{title}</h3><p>{description}</p></div>
                  <ChevronRight className="service-arrow" size={21} aria-hidden="true" />
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="approach" className="slate-panel section-pad" aria-labelledby="approach-title">
          <div className="container method">
            <div>
              <div className="eyebrow" style={{ color: '#FDC97C' }}>The way in</div>
              <h2 id="approach-title" className="display">Insight should<br /><em>steady</em> you.</h2>
              <p className="method-lede">A meaningful reading is not a performance of certainty. It is a private, attentive process that leaves you with better questions, practical context and a little more ground beneath your feet.</p>
            </div>
            <div className="method-steps">
              <div className="step"><div className="step-no">01</div><div><h3>Bring the real question</h3><p>Begin with what is actually on your mind — a choice, a pattern, a transition or a relationship.</p></div></div>
              <div className="step"><div className="step-no">02</div><div><h3>Read the patterns</h3><p>We use the tools that fit the question, with the context of your lived experience always in view.</p></div></div>
              <div className="step"><div className="step-no">03</div><div><h3>Leave with perspective</h3><p>The aim is not dependence. It is a clearer sense of timing, responsibility and what you can do next.</p></div></div>
            </div>
          </div>
        </section>

        <section className="principles section-pad" aria-labelledby="principles-title">
          <div className="container principles-grid">
            <div><div className="eyebrow">A few promises</div><h2 id="principles-title" className="display">Good guidance<br />needs <em>good ground.</em></h2></div>
            <div className="principles-list">
              <div className="principle"><h3>Specific, never sensational</h3><p>We keep the conversation connected to the real circumstances of your life, not dramatic predictions.</p></div>
              <div className="principle"><h3>Your choice remains yours</h3><p>A chart can offer context and timing. It does not replace your judgement, values or responsibility.</p></div>
              <div className="principle"><h3>Private by nature</h3><p>A consultation is a confidential space to ask plainly and be met without judgement.</p></div>
              <div className="principle"><h3>Rooted in tradition</h3><p>Classical systems are approached with respect, while the language stays relevant to life today.</p></div>
            </div>
          </div>
        </section>

        <section id="appointment" className="cream-panel section-pad" aria-labelledby="appointment-title">
          <div className="container faq-contact">
            <div>
              <div className="eyebrow">Before you write</div>
              <h2 id="appointment-title" className="display">A few useful<br />questions.</h2>
              <div className="faq-list">
                {faqs.map(([question, answer], index) => {
                  const isOpen = openFaq === index;
                  return <div className="faq-item" key={question}>
                    <button className="faq-question" onClick={() => setOpenFaq(isOpen ? null : index)} aria-expanded={isOpen} data-testid={`button-faq-${index}`}>
                      <span>{question}</span><Plus className={`faq-icon ${isOpen ? 'open' : ''}`} size={17} />
                    </button>
                    {isOpen && <div className="faq-answer">{answer}</div>}
                  </div>;
                })}
              </div>
            </div>
            <div className="contact-card">
              <div className="eyebrow">Start here</div>
              <h3>Request an appointment</h3>
              <p>Share a little context and your preferred format. This is a client-side form for preparing your enquiry; it does not send a message until a contact method is connected.</p>
              {submitted ? (
                <div className="form-success" role="status" data-testid="status-form-ready">
                  <p><Check size={15} style={{ verticalAlign: 'middle', marginRight: 7 }} />Your enquiry is ready to share. Nothing has been sent.</p>
                  <textarea
                    id="enquiry-preview"
                    className="enquiry-preview"
                    aria-label="Your enquiry draft"
                    readOnly
                    value={submitted}
                    onFocus={(event) => event.currentTarget.select()}
                    rows={6}
                    data-testid="textarea-enquiry-preview"
                  />
                  <button className="button-primary draft-copy" type="button" onClick={copyEnquiry} data-testid="button-copy-enquiry">
                    {copied ? 'Copied' : 'Copy enquiry'} <Copy size={14} />
                  </button>
                  <p className="form-note">{copied ? 'Copied to your clipboard. Send it using the practice’s verified contact method.' : 'Copy this draft, then send it using the practice’s verified contact method.'}</p>
                </div>
              ) : (
                <form className="contact-form" onSubmit={(event) => {
                  event.preventDefault();
                  const formData = new FormData(event.currentTarget);
                  const enquiry = [
                    `Name: ${formData.get('name')}`,
                    `Contact: ${formData.get('email')}`,
                    `Focus: ${formData.get('topic') || 'Not sure yet'}`,
                    `Context: ${formData.get('message') || 'Not provided'}`,
                  ].join('\n');
                  setSubmitted(enquiry);
                  setCopied(false);
                }} data-testid="form-appointment">
                  <div className="field-row">
                    <div className="field"><label htmlFor="name">Your name</label><input id="name" name="name" required placeholder="How should we address you?" data-testid="input-name" /></div>
                    <div className="field"><label htmlFor="email">Email or phone</label><input id="email" name="email" required placeholder="A way to reply" data-testid="input-contact" /></div>
                  </div>
                  <div className="field"><label htmlFor="topic">What would you like to explore?</label><select id="topic" name="topic" defaultValue="" data-testid="select-topic"><option value="" disabled>Select a focus</option><option>Vedic astrology</option><option>Numerology</option><option>Palmistry</option><option>Tantra guidance</option><option>Vastu consultation</option><option>Not sure yet</option></select></div>
                  <div className="field"><label htmlFor="message">A little context</label><textarea id="message" name="message" placeholder="You can keep this brief." data-testid="textarea-context" /></div>
                  <button className="button-primary" type="submit" data-testid="button-submit-appointment">Prepare my enquiry <ArrowUpRight size={15} /></button>
                  <p className="form-note">No payment is taken. No appointment time is invented or reserved here.</p>
                </form>
              )}
            </div>
          </div>
        </section>

        <section className="closing" aria-labelledby="closing-title">
          <div className="container">
            <div className="eyebrow">When the question matters</div>
            <h2 id="closing-title" className="display">Start with one honest <em>question.</em></h2>
            <button className="button-primary" onClick={scrollToContact} data-testid="button-closing-appointment">Request an appointment <ArrowUpRight size={15} /></button>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-inner">
          <small>© {new Date().getFullYear()} Chinmoy Shastri · Durgapur, West Bengal</small>
          <div className="footer-links"><a href="#top" data-testid="link-footer-top">Back to top</a><a href="#services" data-testid="link-footer-services">Services</a><a href="#appointment" data-testid="link-footer-appointment">Appointment</a></div>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;